<?php

namespace SwagAttributeFilter;

use Shopware\Components\Plugin;

class SwagAttributeFilter extends Plugin
{

}
