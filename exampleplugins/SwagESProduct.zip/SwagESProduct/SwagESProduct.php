<?php

namespace SwagESProduct;

use Shopware\Components\Plugin;

class SwagESProduct extends Plugin
{
    
}