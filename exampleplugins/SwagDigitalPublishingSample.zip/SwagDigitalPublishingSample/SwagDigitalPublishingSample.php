<?php

namespace SwagDigitalPublishingSample;

use Shopware\Components\Plugin;

class SwagDigitalPublishingSample extends Plugin
{
    
}