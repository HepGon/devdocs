<?php

namespace SwagTestExample;

use Shopware\Components\Plugin;

class SwagTestExample extends Plugin
{
}
