<?php

namespace SwagESBlog;

use Shopware\Components\Plugin;

class SwagESBlog extends Plugin
{
    
}